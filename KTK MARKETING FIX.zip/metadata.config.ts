import type { Metadata, Viewport } from 'next'

const BASE_URL = 'https://www.khesed-tek-systems.org'

// ─── Viewport (theme-color lives here in Next.js 14+) ────────────────────────
export const viewport: Viewport = {
  themeColor: '#000000',
  width: 'device-width',
  initialScale: 1,
}

// ─── Root metadata ────────────────────────────────────────────────────────────
export const metadata: Metadata = {
  metadataBase: new URL(BASE_URL),

  title: {
    default: 'KHESED-TEK SYSTEMS - Soluciones Tecnológicas para Iglesias',
    template: '%s | KHESED-TEK SYSTEMS',
  },

  description:
    'Soluciones tecnológicas confiables, seguras y elegantes para iglesias y organizaciones. Innovación que impulsa tu misión con excelencia, integridad e innovación.',

  authors: [{ name: 'KHESED-TEK SYSTEMS', url: BASE_URL }],
  creator: 'KHESED-TEK SYSTEMS',
  publisher: 'KHESED-TEK SYSTEMS',
  category: 'Technology',

  // ── Removed "keywords" — Google ignores it since 2009 ──────────────────────
  // keywords: [...] // ← DELETE from your current layout

  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true },
  },

  // ── Canonical + hreflang ───────────────────────────────────────────────────
  alternates: {
    canonical: BASE_URL,
    languages: {
      'es':    BASE_URL,
      'es-CO': BASE_URL,
      'es-MX': BASE_URL,
      'es-AR': BASE_URL,
      'es-CL': BASE_URL,
      'es-PE': BASE_URL,
      'x-default': BASE_URL,
    },
  },

  // ── Open Graph ─────────────────────────────────────────────────────────────
  openGraph: {
    title: 'KHESED-TEK SYSTEMS - Soluciones Tecnológicas para Iglesias',
    description:
      'Soluciones tecnológicas confiables, seguras y elegantes para iglesias y organizaciones.',
    url: BASE_URL,
    siteName: 'KHESED-TEK SYSTEMS',
    locale: 'es_CO',
    type: 'website',
    images: [
      {
        // IMPORTANT: Replace /logo.png with a dedicated 1200×630 OG image.
        // The logo is NOT the right shape — create /public/og-image.png first.
        url: `${BASE_URL}/og-image.png`,
        width: 1200,
        height: 630,
        alt: 'KHESED-TEK SYSTEMS — Tecnología para iglesias en Latinoamérica',
      },
    ],
  },

  // ── Twitter / X ────────────────────────────────────────────────────────────
  twitter: {
    card: 'summary_large_image',
    title: 'KHESED-TEK SYSTEMS - Soluciones Tecnológicas para Iglesias',
    description:
      'Soluciones tecnológicas confiables, seguras y elegantes para iglesias y organizaciones.',
    images: [`${BASE_URL}/og-image.png`],
  },

  // ── Favicon (Next.js reads these from /app/icon.* automatically) ──────────
  // Place these files in /app/:
  //   icon.svg          → served as /favicon.svg
  //   icon.ico          → served as /favicon.ico
  //   apple-icon.png    → served as /apple-touch-icon.png  (180×180)
  //
  // OR declare explicitly:
  icons: {
    icon: [
      { url: '/favicon.ico', sizes: 'any' },
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: [{ url: '/apple-touch-icon.png', sizes: '180x180' }],
  },

  // ── Geo (keep your existing values) ───────────────────────────────────────
  other: {
    'geo.region':   'CO-ATL',
    'geo.placename': 'Barranquilla',
    'geo.position': '10.9878;-74.7889',
    'ICBM':         '10.9878, -74.7889',
  },
}
