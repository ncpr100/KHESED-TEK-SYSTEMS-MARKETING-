'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Check } from 'lucide-react'

type Billing = 'monthly' | 'annual'

const PLANS = [
  {
    name: 'BÁSICO',
    subtitle: 'Iglesia Pequeña',
    monthly: 149.99,
    annual: 124.99, // ~2 months free
    members: 'Hasta 500 miembros',
    licenses: 'Hasta 5 licencias',
    featured: false,
    features: [
      'Gestión básica de miembros',
      'WhatsApp integrado',
      'Hasta 5 licencias',
      'Soporte en español',
      'Pagos PSE / Nequi',
    ],
    cta: 'Solicitar demo',
    href: '/contact?plan=basico',
  },
  {
    name: 'PROFESIONAL',
    subtitle: 'Iglesia Mediana',
    monthly: 299.99,
    annual: 249.99,
    members: 'Hasta 2,000 miembros',
    licenses: 'Hasta 10 licencias',
    featured: true, // ← Most popular
    features: [
      'Todo lo del plan Básico',
      'Hasta 10 licencias',
      'Gestión de eventos y actividades',
      'Reportes avanzados',
      'Transmisiones en vivo',
    ],
    // FIX: changed from "Más popular →" (a label) to an actual action verb
    cta: 'Solicitar demo',
    href: '/contact?plan=profesional',
  },
  {
    name: 'EMPRESARIAL',
    subtitle: 'Iglesia Grande',
    monthly: null,
    annual: null,
    members: 'Miembros ilimitados',
    licenses: 'Licencias ilimitadas',
    featured: false,
    features: [
      'Todo lo del plan Profesional',
      'Licencias ilimitadas',
      'Multi-campus',
      'API personalizada',
      'Soporte prioritario 24/7',
    ],
    cta: 'Solicitar demo',
    href: '/contact?plan=empresarial',
  },
]

export default function PricingSection() {
  const [billing, setBilling] = useState<Billing>('monthly')

  return (
    <section className="max-w-6xl mx-auto px-6 py-12">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-semibold mb-4">
          Planes adaptados al mercado hispano
        </h2>
        <p className="text-[var(--muted)] mb-4">
          Precios justos con métodos de pago locales y soporte en español
        </p>
        <p className="text-lg text-[var(--muted)] mb-4">
          Precio fijo por tamaño de iglesia — Sin cargos adicionales por módulos
        </p>

        {/* Billing toggle */}
        <div className="inline-flex items-center gap-1 bg-[var(--surface)] p-1 rounded-full border border-[var(--border)] mt-4">
          <button
            onClick={() => setBilling('monthly')}
            className={`px-5 py-2 rounded-full text-sm font-medium transition-all ${
              billing === 'monthly'
                ? 'bg-[var(--brand)] text-black'
                : 'text-[var(--muted)] hover:text-[var(--text)]'
            }`}
          >
            Mensual
          </button>
          <button
            onClick={() => setBilling('annual')}
            className={`px-5 py-2 rounded-full text-sm font-medium transition-all ${
              billing === 'annual'
                ? 'bg-[var(--brand)] text-black'
                : 'text-[var(--muted)] hover:text-[var(--text)]'
            }`}
          >
            Anual{' '}
            <span className="text-xs ml-1 opacity-75">2 meses gratis</span>
          </button>
        </div>
      </div>

      {/* Plan cards */}
      <div className="grid md:grid-cols-3 gap-8 mb-12">
        {PLANS.map(plan => (
          <div
            key={plan.name}
            className={`
              relative flex flex-col card p-6 cursor-pointer
              transition-all duration-300 hover:scale-105
              ${plan.featured ? 'scale-105 border-[var(--brand)] shadow-lg' : ''}
            `}
          >
            {/* FIX: "Más popular" is now a badge above the name, not the CTA */}
            {plan.featured && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                <span className="bg-[var(--brand)] text-black text-xs font-semibold px-4 py-1 rounded-full whitespace-nowrap">
                  Más popular
                </span>
              </div>
            )}

            <div className="text-center mb-6 mt-2">
              <h3 className="text-xl font-semibold mb-1">
                {plan.name}
                <span className="block text-sm text-[var(--muted)] font-normal mt-1">
                  {plan.subtitle}
                </span>
              </h3>

              <div className="text-3xl font-bold gradient-text mb-1">
                {plan.monthly === null
                  ? 'Personalizado'
                  : `$${billing === 'monthly' ? plan.monthly : plan.annual} USD`}
                {plan.monthly !== null && (
                  <span className="text-sm text-[var(--muted)] ml-1">/mes</span>
                )}
              </div>
              <div className="text-sm text-[var(--muted)]">{plan.members}</div>
            </div>

            <ul className="space-y-3 mb-8 flex-1">
              {plan.features.map(f => (
                <li key={f} className="flex items-center gap-3 text-sm">
                  <Check className="w-4 h-4 text-green-400 flex-shrink-0" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>

            <Link
              href={plan.href}
              className={`
                w-full text-center font-semibold px-6 py-4 rounded-xl transition-all
                ${plan.featured
                  ? 'gradient-btn text-black hover:shadow-xl rounded-full text-lg'
                  : 'border border-[var(--border)] hover:border-[var(--brand)] hover:bg-[var(--brand)]/10'
                }
              `}
            >
              {plan.cta} →
            </Link>
          </div>
        ))}
      </div>

      {/* FIX: Tax disclaimer for LATAM buyers */}
      <p className="text-center text-sm text-[var(--muted)] mb-8">
        Precios en USD. IVA (19%) no incluido para compradores en Colombia.
        Planes anuales facturados anualmente.{' '}
        <Link href="/contact" className="text-[var(--brand)] hover:underline">
          Consulte métodos de pago locales →
        </Link>
      </p>

      {/* Payment methods */}
      <div className="text-sm text-[var(--muted)] text-center flex items-center justify-center gap-2 flex-wrap">
        <span>Acepta PSE, Nequi, Bancolombia, Efecty y transferencias</span>
        <span className="mx-1">·</span>
        <span>Soporte telefónico incluido en todos los planes</span>
      </div>
    </section>
  )
}
