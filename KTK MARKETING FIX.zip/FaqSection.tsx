'use client'

import { useState } from 'react'
import { ChevronDown } from 'lucide-react'

const FAQ_ITEMS = [
  {
    question: '¿Cuánto cuesta KHESED-TEK-CMS?',
    answer:
      'Tenemos tres planes según el tamaño de su iglesia: Básico ($149.99 USD/mes, hasta 500 miembros), Profesional ($299.99 USD/mes, hasta 2,000 miembros) y Empresarial (precio personalizado, miembros ilimitados). Todos incluyen WhatsApp integrado, soporte en español y métodos de pago locales como PSE y Nequi. Los planes anuales incluyen 2 meses gratis.',
  },
  {
    question: '¿Qué incluye el Programa Beta?',
    answer:
      'El Programa Beta da acceso a KHESED-TEK-CMS antes del lanzamiento oficial. Los participantes obtienen precios especiales de lanzamiento (hasta 40% de descuento), acceso prioritario a nuevas funciones, implementación acompañada por nuestro equipo y la oportunidad de dar retroalimentación directa que moldea el producto.',
  },
  {
    question: '¿Funciona con WhatsApp Business?',
    answer:
      'Sí. Somos el primer sistema de gestión de iglesias (ChMS) con integración nativa de WhatsApp Business. Envíe comunicaciones masivas, recordatorios de eventos, seguimientos pastorales y reciba peticiones de oración directamente desde WhatsApp, sin aplicaciones adicionales ni costos ocultos.',
  },
  {
    question: '¿Cómo migro desde mi sistema actual?',
    answer:
      'Nuestro equipo acompaña la migración completa sin costo adicional. Importamos su base de datos desde Excel, Planning Center, Breeze, ChurchTrac o cualquier sistema anterior. El proceso toma entre 3 y 10 días hábiles según el volumen de datos, con soporte dedicado durante todo el período de transición.',
  },
  {
    question: '¿Están disponibles en mi país?',
    answer:
      'Sí. Operamos en toda Latinoamérica con cobertura confirmada en Colombia, México, Venezuela, Ecuador, Perú, Chile, Argentina, Guatemala, Costa Rica y España. El soporte se brinda en horario LATAM (zona COT, GMT-5) de lunes a viernes de 9AM a 6PM.',
  },
  {
    question: '¿Mis datos están seguros?',
    answer:
      'Todos sus datos se encriptan en tránsito y en reposo con cifrado SSL de 256 bits, el mismo estándar de la banca en línea. Cumplimos con el GDPR y la Ley 1581 de protección de datos de Colombia. Realizamos auditorías de seguridad regulares y garantizamos 99.9% de disponibilidad del servicio.',
  },
  {
    question: '¿Necesito conocimientos técnicos para usarlo?',
    answer:
      'No. KHESED-TEK-CMS está diseñado para pastores, administradores y voluntarios sin perfil técnico. La interfaz está completamente en español y viene con tutoriales en video, documentación detallada y soporte telefónico incluido en todos los planes. Si puede usar WhatsApp, puede usar nuestro sistema.',
  },
  {
    question: '¿Cuándo estará disponible oficialmente?',
    answer:
      'El lanzamiento oficial está programado para 2025. Actualmente estamos en fase Beta con iglesias seleccionadas en Colombia y Latinoamérica. Solicite unirse al Programa Beta para ser de las primeras iglesias en acceder con precios especiales de lanzamiento y acompañamiento personalizado.',
  },
]

export default function FaqSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  const toggle = (i: number) => setOpenIndex(prev => (prev === i ? null : i))

  return (
    <section id="faq" className="max-w-3xl mx-auto px-6 py-16">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-semibold mb-4">Preguntas Frecuentes</h2>
        <p className="text-[var(--muted)] text-lg">
          ¿Tiene dudas? Aquí respondemos las más comunes.
        </p>
      </div>

      <div className="space-y-3">
        {FAQ_ITEMS.map((item, i) => {
          const isOpen = openIndex === i
          return (
            <div
              key={i}
              className="card border transition-all duration-200 border-[var(--border)]"
            >
              <button
                className="w-full text-left px-6 py-5 flex items-center justify-between gap-4 group"
                aria-expanded={isOpen}
                onClick={() => toggle(i)}
              >
                <span className="font-medium transition-colors duration-200 group-hover:text-[var(--brand)]">
                  {item.question}
                </span>
                <ChevronDown
                  className={`flex-shrink-0 w-5 h-5 text-[var(--brand)] transition-transform duration-300 ${
                    isOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {isOpen && (
                <div className="px-6 pb-6 text-[var(--muted)] leading-relaxed">
                  {item.answer}
                </div>
              )}
            </div>
          )
        })}
      </div>

      <div className="text-center mt-10">
        <a
          href="/contact"
          className="inline-flex items-center gap-2 text-[var(--brand)] hover:underline font-medium"
        >
          ¿Otra pregunta? Escríbanos →
        </a>
      </div>
    </section>
  )
}
