/**
 * HEAD ADDITIONS — paste these into your root app/layout.tsx <head> block
 * (or let the metadata.config.ts handle them automatically via Next.js Metadata API)
 *
 * These resolve: missing favicon, missing preconnect, missing theme-color.
 */

// ─── 1. Preconnect hints (add BEFORE the GA script tag) ──────────────────────
//
// <link rel="preconnect" href="https://www.googletagmanager.com" />
// <link rel="preconnect" href="https://www.google-analytics.com" />
// <link rel="dns-prefetch" href="https://static.cloudflareinsights.com" />


// ─── 2. Favicon set (place files in /public/) ────────────────────────────────
//
// Files needed in /public:
//   /public/favicon.ico          (32×32, ICO format)
//   /public/icon.svg             (square SVG favicon, brand colour)
//   /public/apple-touch-icon.png (180×180, no transparent bg)
//
// <link rel="icon" href="/favicon.ico" sizes="any" />
// <link rel="icon" href="/icon.svg" type="image/svg+xml" />
// <link rel="apple-touch-icon" href="/apple-touch-icon.png" />


// ─── 3. Theme color (Android Chrome browser bar) ─────────────────────────────
//
// <meta name="theme-color" content="#000000" />
// NOTE: In Next.js 14+, use the `viewport` export in layout.tsx instead:
//
// export const viewport: Viewport = {
//   themeColor: '#000000',
// }


// ─── 4. Remove the Vercel toolbar from production ────────────────────────────
//
// In next.config.ts:
//
// const nextConfig: NextConfig = {
//   // ... your existing config
// }
//
// In Vercel Dashboard → Project → Settings → Toolbar:
//   → Turn OFF for "Production" environment
//   → Keep ON for "Preview" only
//
// The script tag to remove from layout.tsx:
// <script src="https://vercel.live/_next-live/feedback/feedback.js" ...>  ← DELETE


// ─── 5. OG image — create /public/og-image.png ───────────────────────────────
//
// Required size: 1200 × 630 px
// Suggested content: logo centred on a dark background + tagline below
//   "Tecnología que transforma tu iglesia"
//
// Tools: Canva, Figma, or run this Node script to generate a placeholder:
//
// import sharp from 'sharp'
// await sharp({
//   create: { width: 1200, height: 630, channels: 4, background: '#0a0a0a' }
// })
// .composite([{ input: './public/logo.png', gravity: 'centre' }])
// .png()
// .toFile('./public/og-image.png')


// ─── 6. Minimal favicon SVG (save as /public/icon.svg) ───────────────────────
//
// <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
//   <rect width="32" height="32" rx="6" fill="#000"/>
//   <!-- Replace with your actual logo mark or initial -->
//   <text x="16" y="22" text-anchor="middle" font-family="sans-serif"
//         font-size="18" font-weight="bold" fill="#6EE7FF">K</text>
// </svg>

export {}
