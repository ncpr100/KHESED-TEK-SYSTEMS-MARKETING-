// schemas.ts — Drop these into your layout.tsx <head> via dangerouslySetInnerHTML
// All phone numbers standardised to E.164: +573021234410

export const organizationSchema = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: 'KHESED-TEK SYSTEMS Colombia',
  description:
    'Soluciones tecnológicas para iglesias y organizaciones religiosas en Colombia',
  url: 'https://www.khesed-tek-systems.org',
  logo: 'https://www.khesed-tek-systems.org/logo.png',
  contactPoint: {
    '@type': 'ContactPoint',
    telephone: '+573021234410', // ← Fixed: E.164 format
    contactType: 'sales',
    availableLanguage: 'Spanish',
  },
  address: {
    '@type': 'PostalAddress',
    addressLocality: 'Barranquilla',
    addressRegion: 'Atlántico',
    addressCountry: 'Colombia',
  },
  sameAs: [
    'https://wa.me/573021234410',
    // Add these once profiles are created:
    // 'https://www.linkedin.com/company/khesed-tek-systems',
    // 'https://www.instagram.com/khesed_tek',
    // 'https://www.facebook.com/khesedtek',
    // 'https://www.youtube.com/@khesedteksystems',
  ],
  serviceArea: {
    '@type': 'Country',
    name: 'Colombia y Latinoamérica',
  },
  knowsAbout: [
    'Church Management Systems',
    'Digital Transformation',
    'Custom Software Development',
    'Religious Organization Technology',
    'Colombian Church Technology',
  ],
}

export const localBusinessSchema = {
  '@context': 'https://schema.org',
  '@type': 'LocalBusiness',
  name: 'KHESED-TEK SYSTEMS',
  description: 'Especialistas en tecnología para iglesias y organizaciones religiosas',
  image: 'https://www.khesed-tek-systems.org/logo.png',
  telephone: '+573021234410', // ← Fixed: E.164 format
  email: 'contacto@khesed-tek-systems.org',
  url: 'https://www.khesed-tek-systems.org',
  address: {
    '@type': 'PostalAddress',
    addressLocality: 'Barranquilla',
    addressRegion: 'Atlántico',
    postalCode: '080001',
    addressCountry: 'CO',
  },
  geo: {
    '@type': 'GeoCoordinates',
    latitude: '10.9878',
    longitude: '-74.7889',
  },
  openingHours: 'Mo-Fr 09:00-18:00',
  priceRange: '$$',
  paymentAccepted: 'Cash, Credit Card, Bank Transfer, PSE, Nequi, Bancolombia',
}

export const websiteSchema = {
  '@context': 'https://schema.org',
  '@type': 'WebSite',
  name: 'KHESED-TEK SYSTEMS',
  description: 'Soluciones tecnológicas para iglesias y organizaciones',
  url: 'https://www.khesed-tek-systems.org',
  // ← Fixed: correct SearchAction format per Google spec
  potentialAction: {
    '@type': 'SearchAction',
    target: {
      '@type': 'EntryPoint',
      urlTemplate:
        'https://www.khesed-tek-systems.org/search?q={search_term_string}',
    },
    'query-input': 'required name=search_term_string',
  },
  publisher: {
    '@type': 'Organization',
    name: 'KHESED-TEK SYSTEMS',
    logo: {
      '@type': 'ImageObject',
      url: 'https://www.khesed-tek-systems.org/logo.png',
    },
  },
}

// ── NEW: FAQPage schema — enables Google FAQ rich results ─────────────────────
// Each question here must have a matching visible answer in your FAQ accordion.
export const faqSchema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: [
    {
      '@type': 'Question',
      name: '¿Cuánto cuesta KHESED-TEK-CMS?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'KHESED-TEK-CMS tiene tres planes: Básico ($149.99 USD/mes, hasta 500 miembros), Profesional ($299.99 USD/mes, hasta 2,000 miembros) y Empresarial (precio personalizado, miembros ilimitados). Todos los planes incluyen WhatsApp integrado, soporte en español y métodos de pago locales como PSE y Nequi.',
      },
    },
    {
      '@type': 'Question',
      name: '¿Qué incluye el Programa Beta?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'El Programa Beta permite a iglesias pioneras acceder a KHESED-TEK-CMS antes de su lanzamiento oficial. Los participantes reciben precios especiales de lanzamiento, acceso prioritario a nuevas funciones, acompañamiento personalizado durante la implementación y la oportunidad de dar retroalimentación que moldea el producto.',
      },
    },
    {
      '@type': 'Question',
      name: '¿Funciona con WhatsApp Business?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Sí. KHESED-TEK-CMS es el primer sistema de gestión de iglesias (ChMS) con integración nativa de WhatsApp Business. Puede enviar comunicaciones masivas, recordatorios de eventos, seguimientos pastorales y recibir peticiones de oración directamente desde WhatsApp, sin aplicaciones adicionales.',
      },
    },
    {
      '@type': 'Question',
      name: '¿Cómo migro desde mi sistema actual?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Nuestro equipo acompaña la migración completa sin costo adicional. Importamos su base de datos de miembros desde Excel, Planning Center, Breeze, ChurchTrac o cualquier sistema anterior. El proceso toma entre 3 y 10 días hábiles según el volumen de datos, y usted cuenta con soporte dedicado durante todo el período.',
      },
    },
    {
      '@type': 'Question',
      name: '¿Están disponibles en mi país?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Sí. KHESED-TEK SYSTEMS opera en toda Latinoamérica con cobertura confirmada en Colombia, México, Venezuela, Ecuador, Perú, Chile, Argentina, Guatemala, Costa Rica y España. El soporte se brinda en horario LATAM (zona COT, GMT-5) de lunes a viernes de 9AM a 6PM.',
      },
    },
    {
      '@type': 'Question',
      name: '¿Mis datos están seguros?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Todos los datos se encriptan en tránsito y en reposo con cifrado SSL de 256 bits, el mismo estándar bancario. KHESED-TEK cumple con el Reglamento General de Protección de Datos (GDPR) y las regulaciones colombianas de protección de datos (Ley 1581). Realizamos auditorías de seguridad regulares y garantizamos 99.9% de disponibilidad.',
      },
    },
    {
      '@type': 'Question',
      name: '¿Necesito conocimientos técnicos para usarlo?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'No. KHESED-TEK-CMS está diseñado para pastores, administradores y voluntarios sin perfil técnico. La interfaz está completamente en español y cuenta con tutoriales en video, documentación detallada y soporte telefónico incluido en todos los planes.',
      },
    },
    {
      '@type': 'Question',
      name: '¿Cuándo estará disponible oficialmente?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'El lanzamiento oficial está programado para 2025. Actualmente estamos en fase Beta con iglesias seleccionadas en Colombia y Latinoamérica. Solicite unirse al Programa Beta para ser de las primeras iglesias en acceder al sistema con precios especiales de lanzamiento.',
      },
    },
  ],
}
