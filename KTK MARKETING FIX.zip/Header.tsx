'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { Menu, X } from 'lucide-react'

const NAV_LINKS = [
  { href: '/latam#features', label: 'Funciones' },
  { href: '/latam#about', label: 'Nosotros' },
  { href: '/schedule', label: 'Agendar' },
  { href: '/products', label: 'Productos' },
  { href: '/contact', label: 'Contacto' },
]

export default function Header() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60)
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <header className="sticky top-0 z-50 bg-black/80 backdrop-blur border-b border-[var(--border)]">
      <div className="max-w-6xl mx-auto flex items-center justify-between px-5 py-3">

        {/* Logo */}
        <Link href="/" className="flex items-center" aria-label="KHESED-TEK SYSTEMS — Inicio">
          <Image
            src="/logo.png"
            alt="KHESED-TEK SYSTEMS"
            width={512}
            height={232}
            priority
            className="h-[70px] w-auto sm:h-[90px]"
          />
        </Link>

        {/* Desktop nav */}
        <div className="hidden sm:flex items-center gap-6">
          <nav className="flex gap-6 text-[var(--muted)]" aria-label="Navegación principal">
            {NAV_LINKS.map(link => (
              <Link
                key={link.href}
                href={link.href}
                className="hover:text-[var(--text)] transition"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/*
            FIX: The CTA was permanently hidden with opacity-0 pointer-events-none.
            It now always shows, with a subtle entrance after the user scrolls 60px.
          */}
          <Link
            href="/contact"
            className={`
              inline-flex items-center gap-2 gradient-btn text-black font-semibold
              px-4 py-2 rounded-full text-sm transition-all duration-300
              ${scrolled ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-1 pointer-events-none'}
            `}
            aria-hidden={!scrolled}
            tabIndex={scrolled ? 0 : -1}
          >
            Agendar Demo →
          </Link>
        </div>

        {/* Mobile hamburger */}
        <button
          className="sm:hidden p-2 text-[var(--text)] hover:text-[var(--brand)] transition"
          aria-label={mobileOpen ? 'Cerrar menú' : 'Abrir menú'}
          onClick={() => setMobileOpen(prev => !prev)}
        >
          {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <nav
          className="sm:hidden border-t border-[var(--border)] bg-black/95"
          aria-label="Navegación móvil"
        >
          <div className="flex flex-col px-5 py-4 gap-4">
            {NAV_LINKS.map(link => (
              <Link
                key={link.href}
                href={link.href}
                className="text-[var(--muted)] hover:text-[var(--text)] transition text-base"
                onClick={() => setMobileOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <Link
              href="/contact"
              className="inline-flex items-center justify-center gap-2 gradient-btn text-black font-semibold px-4 py-2 rounded-full text-sm mt-2"
              onClick={() => setMobileOpen(false)}
            >
              Agendar Demo →
            </Link>
          </div>
        </nav>
      )}
    </header>
  )
}
