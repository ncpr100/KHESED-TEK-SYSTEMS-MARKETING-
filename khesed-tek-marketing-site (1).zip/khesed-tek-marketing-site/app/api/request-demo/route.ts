import { NextResponse } from 'next/server';
import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(req: Request) {
  try {
    const formData = await req.formData();
    const payload = {
      name: String(formData.get('name') || '').trim(),
      email: String(formData.get('email') || '').trim(),
      org: String(formData.get('org') || '').trim(),
      whatsapp: String(formData.get('whatsapp') || '').trim(),
      message: String(formData.get('message') || '').trim(),
      wantsDemo: !!formData.get('wantsDemo'),
      receivedAt: new Date().toISOString(),
    };

    if (!payload.name || !payload.email) {
      return NextResponse.json({ ok: false, error: 'Nombre y correo son obligatorios.' }, { status: 400 });
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(payload.email)) {
      return NextResponse.json({ ok: false, error: 'Correo electrónico inválido.' }, { status: 400 });
    }

    const emailBody = `
Nueva solicitud de demo - KHESED-TEK

👤 Nombre: ${payload.name}
📧 Correo: ${payload.email}
🏢 Organización: ${payload.org || 'No especificada'}
📱 WhatsApp: ${payload.whatsapp || 'No especificado'}
🎯 Quiere demo: ${payload.wantsDemo ? 'Sí' : 'No'}

Mensaje:
${payload.message || 'Sin mensaje'}

Recibido: ${new Date(payload.receivedAt).toLocaleString('es-CO', { timeZone: 'America/Bogota' })}
    `.trim();

    const { data, error } = await resend.emails.send({
      from: 'KHESED-TEK Demo <onboarding@resend.dev>',
      to: process.env.CONTACT_EMAIL || 'soporte@khesed-tek.com',
      replyTo: payload.email,
      subject: `Nueva solicitud de demo - ${payload.name}`,
      text: emailBody,
    });

    if (error) {
      console.error('Resend error:', error);
      return NextResponse.json({ ok: false, error: 'Error al enviar el correo.' }, { status: 500 });
    }

    console.log('✓ Demo request sent:', data?.id);
    return NextResponse.json({ ok: true, id: data?.id });
  } catch (err) {
    console.error('Request Demo Error:', err);
    return NextResponse.json({ ok: false, error: 'Error al procesar la solicitud.' }, { status: 500 });
  }
}
