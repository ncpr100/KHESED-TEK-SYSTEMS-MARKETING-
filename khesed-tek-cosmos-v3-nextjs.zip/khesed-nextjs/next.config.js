/** @type {import('next').NextConfig} */
const nextConfig = {
  // Allow images from external domains if needed
  images: {
    domains: ['www.khesed-tek-systems.org'],
  },
};

module.exports = nextConfig;
