'use client';

/**
 * useTheme — Cosmos Design System
 * Manages dark/light theme state, persists to localStorage,
 * and applies data-theme attribute to <html>.
 *
 * Usage:
 *   const { dark, toggle } = useTheme();
 */

import { useState, useEffect, useCallback } from 'react';

export function useTheme() {
  const [dark, setDark] = useState(true);

  useEffect(() => {
    const saved = localStorage.getItem('khesed-theme');
    const isDark = saved !== 'light';
    setDark(isDark);
    document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
  }, []);

  const toggle = useCallback(() => {
    setDark(prev => {
      const next = !prev;
      document.documentElement.setAttribute('data-theme', next ? 'dark' : 'light');
      localStorage.setItem('khesed-theme', next ? 'dark' : 'light');
      return next;
    });
  }, []);

  return { dark, toggle };
}
