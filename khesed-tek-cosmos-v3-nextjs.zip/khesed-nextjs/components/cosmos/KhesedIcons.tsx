/**
 * KhesedIcons — Cosmos Icon System
 *
 * Renders hidden SVG <defs> containing all Khesed-Tek outlined icons.
 * Spec: 24×24 viewBox · 1.5px stroke · round linecap/linejoin
 * Brand language: geometric-faceted forms echoing the logo gem diamond.
 *
 * Usage:
 *   1. Mount <KhesedIcons /> once in layout.tsx (inside <body>)
 *   2. Reference any icon:
 *      <svg width="20" height="20"><use href="#ico-shield" /></svg>
 *
 * Available icons:
 *   ico-globe | ico-message | ico-payment | ico-ai | ico-prayer
 *   ico-chart | ico-culture | ico-shield | ico-lock | ico-uptime
 *   ico-users | ico-support | ico-ministry | ico-connect | ico-email
 *   ico-phone | ico-pin | ico-clock | ico-arrow | ico-chevron
 *   ico-check | ico-play | ico-sun | ico-moon | ico-gem | ico-calc
 *   ico-migrate | ico-linkedin | ico-youtube | ico-facebook
 *   ico-instagram | ico-tiktok
 */

export function KhesedIcons() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" style={{ display: 'none' }}>
      <defs>

        {/* Globe / LATAM */}
        <symbol id="ico-globe" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M2.5 12h19M12 3c-2.5 2.5-4 5.5-4 9s1.5 6.5 4 9M12 3c2.5 2.5 4 5.5 4 9s-1.5 6.5-4 9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </symbol>

        {/* Message / WhatsApp */}
        <symbol id="ico-message" viewBox="0 0 24 24" fill="none">
          <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </symbol>

        {/* Payment */}
        <symbol id="ico-payment" viewBox="0 0 24 24" fill="none">
          <rect x="2" y="5" width="20" height="14" rx="2.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          <path d="M2 10h20" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          <path d="M6 14h4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        </symbol>

        {/* AI / Intelligence */}
        <symbol id="ico-ai" viewBox="0 0 24 24" fill="none">
          <path d="M12 2l2.5 4.5H19l-3 3.5 1.5 5L12 13l-5.5 2 1.5-5-3-3.5h4.5L12 2z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M12 13v9M8 19h8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        </symbol>

        {/* Prayer */}
        <symbol id="ico-prayer" viewBox="0 0 24 24" fill="none">
          <path d="M18 11V8a2 2 0 0 0-4 0v3M6 11V8a2 2 0 0 1 4 0v3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M6 11h12v5a5 5 0 0 1-5 5h-2a5 5 0 0 1-5-5v-5z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M12 2v2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        </symbol>

        {/* Chart / Analytics */}
        <symbol id="ico-chart" viewBox="0 0 24 24" fill="none">
          <path d="M3 3v18h18" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M7 16l4-6 4 3 4-8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          <circle cx="19" cy="5" r="1.5" stroke="currentColor" strokeWidth="1"/>
        </symbol>

        {/* Culture */}
        <symbol id="ico-culture" viewBox="0 0 24 24" fill="none">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M2 12h20M12 2c-2.76 3.36-4 6.72-4 10s1.24 6.64 4 10M12 2c2.76 3.36 4 6.72 4 10s-1.24 6.64-4 10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        </symbol>

        {/* Shield */}
        <symbol id="ico-shield" viewBox="0 0 24 24" fill="none">
          <path d="M12 2l8 3.5V12c0 4.5-3.5 8.5-8 10-4.5-1.5-8-5.5-8-10V5.5L12 2z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M9 12l2 2 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </symbol>

        {/* Lock / SSL */}
        <symbol id="ico-lock" viewBox="0 0 24 24" fill="none">
          <rect x="5" y="11" width="14" height="11" rx="2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          <path d="M8 11V7a4 4 0 0 1 8 0v4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          <circle cx="12" cy="16" r="1.5" stroke="currentColor" strokeWidth="1"/>
        </symbol>

        {/* Uptime */}
        <symbol id="ico-uptime" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M8.5 12l2.5 2.5 4-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </symbol>

        {/* Users */}
        <symbol id="ico-users" viewBox="0 0 24 24" fill="none">
          <circle cx="9" cy="7" r="3.5" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M2 21v-1a7 7 0 0 1 14 0v1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          <path d="M16 3.5a3.5 3.5 0 1 1 0 7M22 21v-1a7 7 0 0 0-5-6.7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        </symbol>

        {/* Support / Headset */}
        <symbol id="ico-support" viewBox="0 0 24 24" fill="none">
          <path d="M3 18v-6a9 9 0 0 1 18 0v6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          <path d="M21 18a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M3 18a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </symbol>

        {/* Ministry / cross */}
        <symbol id="ico-ministry" viewBox="0 0 24 24" fill="none">
          <path d="M12 2v20M2 12h20" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          <path d="M8 7l4-4 4 4M16 17l-4 4-4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </symbol>

        {/* Connect / integrations */}
        <symbol id="ico-connect" viewBox="0 0 24 24" fill="none">
          <circle cx="5" cy="12" r="2.5" stroke="currentColor" strokeWidth="1.5"/>
          <circle cx="19" cy="6" r="2.5" stroke="currentColor" strokeWidth="1.5"/>
          <circle cx="19" cy="18" r="2.5" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M7.5 12l9-6M7.5 12l9 6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        </symbol>

        {/* Email */}
        <symbol id="ico-email" viewBox="0 0 24 24" fill="none">
          <rect x="2" y="4" width="20" height="16" rx="2.5" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M2 8l10 6 10-6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </symbol>

        {/* Phone */}
        <symbol id="ico-phone" viewBox="0 0 24 24" fill="none">
          <path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3-8.6A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.8a2 2 0 0 1-.4 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.8.3 1.8.6 2.8.7A2 2 0 0 1 22 16.9z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </symbol>

        {/* Location pin */}
        <symbol id="ico-pin" viewBox="0 0 24 24" fill="none">
          <path d="M12 22s-8-5.5-8-12a8 8 0 0 1 16 0c0 6.5-8 12-8 12z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          <circle cx="12" cy="10" r="2.5" stroke="currentColor" strokeWidth="1.5"/>
        </symbol>

        {/* Clock */}
        <symbol id="ico-clock" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M12 7v5l3 2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </symbol>

        {/* Arrow right */}
        <symbol id="ico-arrow" viewBox="0 0 24 24" fill="none">
          <path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </symbol>

        {/* Chevron down */}
        <symbol id="ico-chevron" viewBox="0 0 24 24" fill="none">
          <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </symbol>

        {/* Check mark */}
        <symbol id="ico-check" viewBox="0 0 24 24" fill="none">
          <path d="M20 6L9 17l-5-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </symbol>

        {/* Play */}
        <symbol id="ico-play" viewBox="0 0 24 24" fill="none">
          <path d="M8 5.5l11 6.5-11 6.5V5.5z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="currentColor"/>
        </symbol>

        {/* Sun — light mode toggle */}
        <symbol id="ico-sun" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="4" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M12 2v2M12 20v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M2 12h2M20 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        </symbol>

        {/* Moon — dark mode toggle */}
        <symbol id="ico-moon" viewBox="0 0 24 24" fill="none">
          <path d="M21 12.8A9 9 0 0 1 11.2 3 9 9 0 1 0 21 12.8z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </symbol>

        {/* Diamond gem — brand mark */}
        <symbol id="ico-gem" viewBox="0 0 24 24" fill="none">
          <path d="M6 3h12l4 6-10 13L2 9l4-6z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M2 9h20M12 3l4 6-4 13-4-13 4-6z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </symbol>

        {/* ROI Calculator */}
        <symbol id="ico-calc" viewBox="0 0 24 24" fill="none">
          <rect x="4" y="2" width="16" height="20" rx="2" stroke="currentColor" strokeWidth="1.5"/>
          <rect x="7" y="5" width="10" height="4" rx="1" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M7 13h2M11 13h2M15 13h2M7 17h2M11 17h2M15 17h2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        </symbol>

        {/* Migrate / import */}
        <symbol id="ico-migrate" viewBox="0 0 24 24" fill="none">
          <path d="M4 12h16M14 6l6 6-6 6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M4 6v12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeDasharray="2 2"/>
        </symbol>

        {/* LinkedIn */}
        <symbol id="ico-linkedin" viewBox="0 0 24 24" fill="currentColor">
          <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6zM2 9h4v12H2zM4 6a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"/>
        </symbol>

        {/* YouTube */}
        <symbol id="ico-youtube" viewBox="0 0 24 24" fill="currentColor">
          <path d="M22.5 6.4a2.8 2.8 0 0 0-2-2C18.9 4 12 4 12 4s-6.9 0-8.5.4a2.8 2.8 0 0 0-2 2A29 29 0 0 0 1 12a29 29 0 0 0 .5 5.6 2.8 2.8 0 0 0 2 2C5.1 20 12 20 12 20s6.9 0 8.5-.4a2.8 2.8 0 0 0 2-2A29 29 0 0 0 23 12a29 29 0 0 0-.5-5.6z"/>
          <polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02" fill="white"/>
        </symbol>

        {/* Facebook */}
        <symbol id="ico-facebook" viewBox="0 0 24 24" fill="currentColor">
          <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>
        </symbol>

        {/* Instagram */}
        <symbol id="ico-instagram" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <rect x="2" y="2" width="20" height="20" rx="5" ry="5"/>
          <circle cx="12" cy="12" r="4"/>
          <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/>
        </symbol>

        {/* TikTok */}
        <symbol id="ico-tiktok" viewBox="0 0 24 24" fill="currentColor">
          <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34V8.69a8.18 8.18 0 0 0 4.78 1.52V6.75a4.85 4.85 0 0 1-1.01-.06z"/>
        </symbol>

      </defs>
    </svg>
  );
}
