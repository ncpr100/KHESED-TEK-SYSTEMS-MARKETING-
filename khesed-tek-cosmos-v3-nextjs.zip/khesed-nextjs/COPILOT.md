# KHESED-TEK SYSTEMS — Cosmos Design System v3
## GitHub Copilot Implementation Guide

---

## Project Structure

```
khesed-nextjs/
├── app/
│   ├── layout.tsx              ← Root layout: mounts icons + canvas
│   └── page.tsx                ← Full homepage (single file)
├── components/
│   └── cosmos/
│       ├── CosmosBackground.tsx  ← Animated star field canvas
│       ├── KhesedIcons.tsx       ← 32-icon SVG symbol system
│       └── useTheme.ts           ← Dark/light theme hook
├── styles/
│   ├── cosmos-tokens.css       ← Design tokens (import FIRST)
│   └── page-styles.css         ← All component & section CSS
├── public/
│   └── images/
│       └── demo-thumbnail-latam.png  ← Replace with actual video thumbnail
├── next.config.js
├── package.json
└── tsconfig.json
```

---

## Step 1 — Install Dependencies

```bash
npm install
# or
yarn install
```

---

## Step 2 — CSS Import Order

In `app/globals.css` (or confirm layout.tsx already imports both):

```css
/* 1. Tokens MUST come first */
@import '../styles/cosmos-tokens.css';

/* 2. Page styles second */
@import '../styles/page-styles.css';
```

Both are already imported directly in `layout.tsx` — no globals.css needed unless you have existing global styles to merge.

---

## Step 3 — Update Social Media URLs

Search the file `app/page.tsx` for `khesedtek` and replace with your actual handles:

| Platform  | Current placeholder              | Replace with |
|-----------|----------------------------------|--------------|
| Facebook  | `facebook.com/khesedtek`         | Your FB page URL |
| Instagram | `instagram.com/khesedtek`        | Your IG handle |
| TikTok    | `tiktok.com/@khesedtek`          | Your TikTok handle |
| LinkedIn  | already correct                  | — |
| YouTube   | already correct                  | — |

---

## Step 4 — Add Video Thumbnail

Replace `/public/images/demo-thumbnail-latam.png` with your actual YouTube video thumbnail.

For production, swap the `<img>` tag in `page.tsx` (search: `demo-thumbnail-latam`) with Next.js `Image`:

```tsx
import Image from 'next/image';

// Replace:
<img src="/images/demo-thumbnail-latam.png" alt="..." />

// With:
<Image
  src="/images/demo-thumbnail-latam.png"
  alt="Historia del Fundador de KHESED-TEK"
  fill
  style={{ objectFit: 'cover' }}
  priority
/>
```

---

## Step 5 — Run Development Server

```bash
npm run dev
# Open http://localhost:3000
```

---

## Theme System

The `data-theme` attribute on `<html>` controls all CSS variables.

```tsx
// In any client component:
import { useTheme } from '@/components/cosmos/useTheme';
const { dark, toggle } = useTheme();
```

Switching theme:
- Sets `data-theme="dark"` or `data-theme="light"` on `<html>`
- Persists to `localStorage` under key `khesed-theme`
- `CosmosBackground` observes the attribute change and re-renders

---

## Icon System

All 32 icons are defined as SVG `<symbol>` elements in `KhesedIcons.tsx`.
Reference any icon anywhere in the app:

```tsx
<svg width="20" height="20" style={{ color: 'var(--gold-hi)' }}>
  <use href="#ico-shield" />
</svg>
```

Available icon IDs:
`ico-globe` `ico-message` `ico-payment` `ico-ai` `ico-prayer` `ico-chart`
`ico-culture` `ico-shield` `ico-lock` `ico-uptime` `ico-users` `ico-support`
`ico-ministry` `ico-connect` `ico-email` `ico-phone` `ico-pin` `ico-clock`
`ico-arrow` `ico-chevron` `ico-check` `ico-play` `ico-sun` `ico-moon`
`ico-gem` `ico-calc` `ico-migrate` `ico-linkedin` `ico-youtube`
`ico-facebook` `ico-instagram` `ico-tiktok`

---

## Logo Usage

The `KhesedLogo` component is defined inside `page.tsx`.
Extract it to a shared component file for reuse across pages:

```tsx
// components/cosmos/KhesedLogo.tsx
'use client';
export function KhesedLogo({ height = 46 }: { height?: number }) {
  // ... copy from page.tsx
}
```

The logo concept: **the cross structurally replaces the T in TEK.**
KHESED → flows through → ✝ (= T) → completes → EK → SYSTEMS

---

## CSS Token Reference

| Token | Dark | Light |
|-------|------|-------|
| `--bg` | `#05080F` | `#F5F0E8` |
| `--srf` | `rgba(13,22,40,0.72)` | `rgba(255,255,255,0.90)` |
| `--srf-lo` | `rgba(13,22,40,0.42)` | `rgba(240,234,218,0.60)` |
| `--bdr` | `rgba(201,146,42,0.14)` | `rgba(160,120,50,0.18)` |
| `--txt` | `#F0EDE8` | `#0D1628` |
| `--muted` | `#7A8A9E` | `#5A6478` |
| `--gold-hi` | `#F0B83C` | `#F0B83C` |
| `--cyan` | `#26D9D9` | `#26D9D9` |
| `--emerald` | `#1DC98C` | `#1DC98C` |

---

## Copilot Prompts

Use these prompts inside GitHub Copilot Chat to extend the project:

**Extract sections into components:**
> "Extract the FAQ section from page.tsx into a separate Client Component at components/cosmos/FaqSection.tsx, keeping all existing styles and state logic"

**Add a contact form:**
> "Add a contact form section to page.tsx after the contact info cards, using the existing glass card style (var(--srf) background, var(--bdr-s) border, backdrop-filter blur), with fields for name, church, email, and message, and a submit button using the btn-primary class"

**Add animation on pricing cards:**
> "Add a subtle shimmer animation to the popular pricing card using the existing shimmer keyframe from cosmos-tokens.css"

**Convert to next/image:**
> "Find all img tags in page.tsx and convert them to the Next.js Image component with appropriate width, height, and priority props"

**Add Google Analytics:**
> "Add Google Analytics gtag to layout.tsx using the existing GA ID G-J8QN6G9SQN, following Next.js App Router best practices with the Script component"

---

## Deployment

### Vercel (recommended)
```bash
npx vercel --prod
```

### GitHub Pages / Static Export
Add to `next.config.js`:
```js
const nextConfig = {
  output: 'export',
  trailingSlash: true,
};
```

Then:
```bash
npm run build
# Deploy the /out folder
```

---

## Design System Principles

1. **Zero emoji** — all visual elements use the Khesed SVG icon system
2. **Consistent stroke weight** — 1.5px on all outline icons, matching the logo cross
3. **Two theme surfaces** — `--srf` (72% opacity glass) and `--srf-lo` (42% opacity) for depth
4. **Gold as the only accent** — `var(--gold-hi)` for primary, `var(--cyan)` for secondary tech elements
5. **Cinzel for all headings** — DM Sans for body text, never mix
6. **The cross completes the wordmark** — never display the logo as plain text

---

*KHESED-TEK SYSTEMS · Barranquilla, Colombia · contacto@khesed-tek-systems.org*
