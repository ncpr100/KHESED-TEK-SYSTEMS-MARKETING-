import type { Metadata } from 'next';
import { KhesedIcons } from '@/components/cosmos/KhesedIcons';
import { CosmosBackground } from '@/components/cosmos/CosmosBackground';
import '../styles/cosmos-tokens.css';
import '../styles/page-styles.css';

export const metadata: Metadata = {
  title: 'KHESED-TEK SYSTEMS — Soluciones Tecnológicas para Iglesias',
  description:
    'Soluciones tecnológicas confiables, seguras y elegantes para iglesias y organizaciones. Innovación que impulsa tu misión con excelencia, integridad e innovación.',
  authors: [{ name: 'KHESED-TEK SYSTEMS' }],
  creator: 'KHESED-TEK SYSTEMS',
  publisher: 'KHESED-TEK SYSTEMS',
  robots: { index: true, follow: true },
  alternates: {
    canonical: 'https://www.khesed-tek-systems.org',
    languages: {
      'es-419': 'https://www.khesed-tek-systems.org',
      'es':     'https://www.khesed-tek-systems.org',
      'en-US':  'https://www.khesed-tek-systems.org/usa',
      'en':     'https://www.khesed-tek-systems.org/global',
    },
  },
  openGraph: {
    title: 'KHESED-TEK SYSTEMS — Soluciones Tecnológicas para Iglesias',
    description: 'Soluciones tecnológicas confiables, seguras y elegantes para iglesias y organizaciones.',
    siteName: 'KHESED-TEK SYSTEMS',
    locale: 'es_CO',
    type: 'website',
    images: [{
      url: 'https://www.khesed-tek-systems.org/og-image.png',
      width: 1200, height: 630,
      alt: 'KHESED-TEK SYSTEMS — Tecnología para iglesias en Latinoamérica',
    }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'KHESED-TEK SYSTEMS — Soluciones Tecnológicas para Iglesias',
    description: 'Soluciones tecnológicas confiables, seguras y elegantes para iglesias y organizaciones.',
    images: ['https://www.khesed-tek-systems.org/og-image.png'],
  },
  other: {
    'geo.region':    'CO-ATL',
    'geo.placename': 'Barranquilla',
    'geo.position':  '10.9878;-74.7889',
    'ICBM':          '10.9878, -74.7889',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es" data-theme="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="shortcut icon" href="/favicon-16x16.png" />
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <link rel="manifest" href="/site.webmanifest" />
        <meta name="theme-color" content="#000000" />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'Organization',
          name: 'KHESED-TEK SYSTEMS Colombia',
          description: 'Soluciones tecnológicas para iglesias y organizaciones religiosas en Colombia',
          url: 'https://www.khesed-tek-systems.org',
          contactPoint: { '@type': 'ContactPoint', telephone: '+573021234410', contactType: 'sales', availableLanguage: 'Spanish' },
          address: { '@type': 'PostalAddress', streetAddress: 'La Campiña, Localidad Norte - Centro Histórico', addressLocality: 'Barranquilla', addressRegion: 'Atlántico', postalCode: '80020', addressCountry: 'CO' },
          sameAs: ['https://wa.me/573021234410','https://linkedin.com/company/khesed-tek-systems','https://www.youtube.com/@khesed-tek','https://facebook.com/khesedtek','https://instagram.com/khesedtek','https://tiktok.com/@khesedtek'],
          serviceArea: { '@type': 'Country', name: 'Colombia y Latinoamérica' },
        })}} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'LocalBusiness',
          name: 'KHESED-TEK SYSTEMS',
          telephone: '+573021234410',
          email: 'contacto@khesed-tek-systems.org',
          url: 'https://www.khesed-tek-systems.org',
          address: { '@type': 'PostalAddress', streetAddress: 'La Campiña, Localidad Norte - Centro Histórico', addressLocality: 'Barranquilla', addressRegion: 'Atlántico', postalCode: '80020', addressCountry: 'CO' },
          geo: { '@type': 'GeoCoordinates', latitude: '10.9878', longitude: '-74.7889' },
          openingHours: 'Mo-Fr 09:00-18:00',
          priceRange: '$$',
          paymentAccepted: 'Cash, Credit Card, Bank Transfer, Nequi, PSE, Efecty',
        })}} />
      </head>
      <body>
        {/* SVG icon system — renders hidden defs, must come before any icon usage */}
        <KhesedIcons />
        {/* Living star field canvas — fixed z-0, behind all content */}
        <CosmosBackground />
        {/* All page content */}
        {children}
      </body>
    </html>
  );
}
