'use client';

/**
 * KHESED-TEK SYSTEMS — Cosmos Homepage
 * Next.js App Router · page.tsx
 *
 * SETUP (run once after copying files):
 *   1. app/globals.css → add: @import '../styles/cosmos-tokens.css';
 *                              @import '../styles/page-styles.css';
 *   2. app/layout.tsx → import KhesedIcons and CosmosBackground,
 *      mount them inside <body> before {children}
 *   3. Update social media URLs (search: khesedtek) to your real handles
 *   4. Replace /images/demo-thumbnail-latam.png with your actual thumbnail
 *
 * GitHub Copilot prompt to scaffold this page:
 *   "Convert this React component to use Next.js Image for the video thumbnail
 *    and extract each section into its own component file"
 */

import { useEffect, useRef, useCallback } from 'react';
import { useTheme } from '@/components/cosmos/useTheme';

/* ─── LOGO MARK (inline SVG — refined Logo 1) ─────────────── */
function KhesedLogo({ height = 46 }: { height?: number }) {
  return (
    <svg
      viewBox="0 0 370 68"
      xmlns="http://www.w3.org/2000/svg"
      style={{ height, width: 'auto' }}
      aria-label="KHESED-TEK SYSTEMS"
    >
      {/* KHESED */}
      <text x="2" y="52" fontFamily="'Cinzel',Georgia,serif" fontWeight="700" fontSize="52" fill="var(--gold-hi)" letterSpacing="-0.5">KHESED</text>
      {/* Cross — structurally replaces the T in TEK */}
      <rect x="213" y="2" width="7" height="64" rx="2.5" fill="var(--gold-hi)"/>
      <rect x="196" y="17" width="41" height="6" rx="2.5" fill="var(--gold-hi)"/>
      {/* Hand */}
      <g transform="translate(200,36)" fill="none" stroke="var(--gold-hi)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M8 20C3 19 2 13 3 9c0-2 1-3 3-3V3c0-1 1-1.5 2-1s2 .5 2 1.5V5c1-.5 2 0 2 1.5V7c1-.5 2 0 2 2v8c0 3-2 5-4 5z"/>
        <path d="M6 6v5M10 3v7M14 7v6"/>
      </g>
      {/* Dove */}
      <g transform="translate(204,5)" fill="none" stroke="var(--gold-hi)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M10 13C7 12 3 10 2 7 0 4 2 1 5 3 4 1 5 0 7 1c1-1 3 0 4 2 2-1 4 1 3 3-1 2-3 4-4 7z"/>
        <path d="M10 13l-1 7M7 5L4 4"/>
      </g>
      {/* Flame */}
      <g transform="translate(212.5,8)" fill="var(--gold-hi)" opacity="0.88">
        <path d="M3 10C3 10 0 7 1 4c.5-1.5 2-3 2-3s1.5 1.5 2 3c1.5 3 1.5 6-2 6z"/>
      </g>
      {/* EK */}
      <text x="237" y="52" fontFamily="'Cinzel',Georgia,serif" fontWeight="700" fontSize="52" fill="var(--gold-hi)" letterSpacing="-0.5">EK</text>
      {/* SYSTEMS — centered under full mark */}
      <text x="185" y="67" fontFamily="'Cinzel',Georgia,serif" fontWeight="400" fontSize="12" fill="var(--gold-hi)" letterSpacing="5" textAnchor="middle" opacity="0.75">SYSTEMS</text>
    </svg>
  );
}

/* ─── ICON SHORTHAND ───────────────────────────────────────── */
function Icon({ id, size = 20, color, style }: {
  id: string; size?: number; color?: string; style?: React.CSSProperties;
}) {
  return (
    <svg width={size} height={size} style={{ color, flexShrink: 0, display: 'block', ...style }}>
      <use href={`#${id}`} />
    </svg>
  );
}

/* ─── LIVE DOT ─────────────────────────────────────────────── */
function LiveDot() {
  return (
    <span style={{
      display: 'inline-block', width: 6, height: 6, borderRadius: '50%',
      background: 'var(--emerald)', boxShadow: '0 0 8px var(--emerald)',
      animation: 'pulse-live 1.5s ease-in-out infinite', flexShrink: 0,
    }} />
  );
}

/* ─── SCROLL REVEAL HOOK ───────────────────────────────────── */
function useScrollReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      entries => entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.classList.add('in');
          observer.unobserve(e.target);
        }
      }),
      { threshold: 0.1 }
    );
    document.querySelectorAll('.rv').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

/* ─── ROI CALCULATOR LOGIC ─────────────────────────────────── */
function calcROI(cost: number, hrs: number, manual: number): { save: number; hrsSaved: number } {
  const eff = 0.30 + (manual / 10) * 0.20;
  const save = Math.round(cost * 0.35 + hrs * 4 * 8 * eff);
  const hrsSaved = Math.round(hrs * eff);
  return { save, hrsSaved };
}

/* ════════════════════════════════════════════════════════════
   PAGE COMPONENT
════════════════════════════════════════════════════════════ */
export default function HomePage() {
  const { dark, toggle } = useTheme();
  useScrollReveal();

  /* Pricing state */
  const [annual, setAnnual] = React.useState(false);
  const prices = {
    basic: annual ? '$124.99' : '$149.99',
    pro:   annual ? '$249.99' : '$299.99',
  };

  /* ROI state */
  const [roiCost, setRoiCost]     = React.useState(200);
  const [roiHrs, setRoiHrs]       = React.useState(15);
  const [roiManual, setRoiManual] = React.useState(5);
  const [roiResult, setRoiResult] = React.useState<{ save: number; hrsSaved: number } | null>(null);

  /* FAQ state */
  const [openFaq, setOpenFaq] = React.useState<number | null>(null);

  const faqs = [
    {
      q: '¿Cuánto cuesta KHESED-TEK-CMS?',
      a: 'El plan Básico (hasta 500 miembros) comienza en $149.99 USD/mes. El plan Profesional (hasta 2,000 miembros) es $299.99 USD/mes. Las iglesias grandes reciben un precio personalizado. Todos los planes incluyen soporte en español y métodos de pago locales. Paddle, nuestro procesador de pagos, convierte automáticamente a su moneda local.',
    },
    {
      q: '¿Qué incluye el Programa Beta?',
      a: 'El Programa Beta ofrece 30 días de acceso completo a la plataforma sin costo. Los participantes obtienen precios especiales de lanzamiento (hasta 40% de descuento), acceso prioritario a nuevas funciones, implementación acompañada por nuestro equipo y la oportunidad de dar retroalimentación directa que moldea el producto.',
    },
    {
      q: '¿Funciona con WhatsApp Business?',
      a: 'Sí — somos el único ChMS con WhatsApp Business completamente integrado. Puede enviar recordatorios de eventos, comunicados pastorales, seguimientos de oración y notificaciones administrativas directamente desde la plataforma. Planning Center, Breeze y otros competidores internacionales no tienen esta funcionalidad.',
    },
    {
      q: '¿Cómo migro desde mi sistema actual?',
      a: 'Nuestro equipo en Barranquilla le acompaña en todo el proceso de migración sin costo adicional. Importamos su base de datos desde Excel, Planning Center, Breeze, ChurchTrac o cualquier sistema anterior. El proceso toma entre 3 y 10 días hábiles según el volumen de datos.',
    },
    {
      q: '¿Están disponibles en mi país?',
      a: 'Sí — operamos en toda Latinoamérica con sede en Barranquilla, Colombia. Nuestro soporte está disponible en horario LATAM (lunes a viernes, 9AM–6PM COT). Aceptamos métodos de pago locales como PSE, Nequi, Efecty, Bancolombia y transferencias bancarias.',
    },
    {
      q: '¿Mis datos están seguros?',
      a: 'Absolutamente. Toda la información de su iglesia se almacena en servidores seguros con cifrado SSL de 256 bits en tránsito y en reposo, el mismo estándar de la banca en línea. Cumplimos con el GDPR y la Ley 1581 de protección de datos de Colombia.',
    },
    {
      q: '¿Necesito conocimientos técnicos para usarlo?',
      a: 'No. La plataforma está diseñada para pastores y administradores de iglesia, no para técnicos. La interfaz es en español, intuitiva y funciona desde cualquier dispositivo. Si su equipo sabe usar WhatsApp, puede manejar KHESED-TEK-CMS.',
    },
    {
      q: '¿Cómo calcula la Calculadora de ROI los ahorros?',
      a: 'La calculadora combina tres variables. Primero, reduce su costo actual de software en un 35% — el ahorro promedio al consolidar herramientas en una sola plataforma. Segundo, toma sus horas administrativas semanales y aplica un factor de eficiencia entre 30% y 50% según el nivel de procesos manuales. Tercero, ajusta el total según su objetivo de crecimiento. El resultado es una estimación basada en benchmarks de la industria — no una garantía contractual. Durante su demo gratuita, nuestro equipo puede hacer un análisis personalizado.',
    },
    {
      q: '¿Cuándo estará disponible oficialmente?',
      a: 'Actualmente estamos en fase Beta con iglesias seleccionadas. El lanzamiento oficial está planificado para los próximos meses. Las iglesias que se unan ahora al programa Beta tendrán precio preferencial congelado y acceso prioritario a nuevas funciones.',
    },
  ];

  const features = [
    { badge: 'Exclusivo',     icon: 'ico-message',  color: 'var(--cyan)',    title: 'WhatsApp Business Nativo',        desc: 'Primer ChMS con WhatsApp Business completamente integrado. Envíe recordatorios, comunicados pastorales y seguimientos directamente desde la plataforma. Planning Center, Breeze y otros no tienen esta funcionalidad esencial para Latinoamérica.',               vs: 'vs Todos: Único con WhatsApp Business nativo' },
    { badge: 'Cultural',      icon: 'ico-payment',  color: 'var(--gold-hi)', title: 'Métodos de Pago LATAM',           desc: 'Nequi, PSE, transferencias bancarias locales incluidas. Los competidores internacionales solo ofrecen Stripe y PayPal. Acepte donaciones y pagos con los métodos que su congregación ya usa.',                                                           vs: 'vs Internacionales: Pagos locales 100% integrados' },
    { badge: 'IA Avanzada',   icon: 'ico-ai',       color: 'var(--emerald)', title: 'Emparejamiento Inteligente',      desc: 'IA empareja voluntarios con ministerios basado en dones espirituales. ChurchTrac y Breeze solo tienen programación básica. Nuestro algoritmo conecta personas con el ministerio perfecto.',                                                                vs: 'vs ChurchTrac/Breeze: IA única para voluntarios' },
    { badge: 'Automatización',icon: 'ico-prayer',   color: 'var(--gold-hi)', title: 'Motor de Oración Automatizado',   desc: 'Sistema único de seguimiento pastoral con IA para análisis emocional. Ningún competidor tiene automatización pastoral. Detecta peticiones críticas y enruta al pastor en tiempo real.',                                                                    vs: 'vs Todos: Automatización pastoral exclusiva' },
    { badge: 'Cultural',      icon: 'ico-culture',  color: 'var(--cyan)',    title: 'Adaptación Cultural IA',          desc: 'Sistema que adapta automáticamente la interfaz al contexto cultural latino. Los competidores usan traducciones básicas. Nosotros entendemos la iglesia hispana desde adentro.',                                                                        vs: 'vs Todos: Adaptación cultural inteligente' },
    { badge: 'Predictivo',    icon: 'ico-chart',    color: '#9B8FFF',        title: 'Análisis de Participación',       desc: 'IA predice deserción de miembros y sugiere intervenciones. Planning Center solo tiene reportes básicos. Intervenga antes de que una oveja se aleje del rebaño.',                                                                                     vs: 'vs Planning Center: Predicción avanzada única' },
  ];

  const trustItems = [
    { icon: 'ico-lock',     val: '256-bit', lbl: 'SSL Seguro',     desc: 'Encriptación de nivel bancario' },
    { icon: 'ico-shield',   val: 'GDPR',    lbl: 'Cumplimiento',   desc: 'Protección de datos completa' },
    { icon: 'ico-uptime',   val: '99.9%',   lbl: 'Disponibilidad', desc: 'Uptime garantizado' },
    { icon: 'ico-users',    val: '10K+',    lbl: 'Capacidad',      desc: 'Miembros soportados' },
    { icon: 'ico-support',  val: '24/7',    lbl: 'Soporte',        desc: 'Disponible cuando lo necesitas' },
    { icon: 'ico-ministry', val: '40+',     lbl: 'Experiencia',    desc: 'Años de experiencia ministerial' },
    { icon: 'ico-connect',  val: '15+',     lbl: 'Integraciones',  desc: 'Conecta tus herramientas' },
  ];

  const socials = [
    { id: 'ico-linkedin',  href: 'https://linkedin.com/company/khesed-tek-systems', label: 'LinkedIn' },
    { id: 'ico-youtube',   href: 'https://www.youtube.com/@khesed-tek',              label: 'YouTube' },
    { id: 'ico-facebook',  href: 'https://facebook.com/khesedtek',                  label: 'Facebook' },
    { id: 'ico-instagram', href: 'https://instagram.com/khesedtek',                 label: 'Instagram' },
    { id: 'ico-tiktok',    href: 'https://tiktok.com/@khesedtek',                   label: 'TikTok' },
  ];

  return (
    <>
      {/* ── HEADER ───────────────────────────────────────────── */}
      <header>
        <a href="/" style={{ display: 'flex', alignItems: 'center', textDecoration: 'none' }}>
          <KhesedLogo height={46} />
        </a>

        <nav>
          <a href="#features">Funciones</a>
          <a href="#about">Nosotros</a>
          <a href="/schedule">Agendar</a>
          <a href="/products">Productos</a>
          <a href="#contact">Contacto</a>
        </nav>

        <div className="hd-right">
          <a href="/contact" className="btn-demo">Agendar Demo</a>
          <button className="btn-theme" onClick={toggle} aria-label="Cambiar tema">
            <Icon id={dark ? 'ico-sun' : 'ico-moon'} size={16} color="var(--gold-hi)" />
          </button>
        </div>
      </header>

      {/* ── HERO ─────────────────────────────────────────────── */}
      <section id="hero">
        <div style={{ maxWidth: 820, textAlign: 'center' }}>
          <div className="eyebrow">
            <LiveDot />
            <Icon id="ico-globe" size={14} color="var(--cyan)" />
            Mercado LATAM — Especialistas en mercado hispano
          </div>

          <h1>Tecnología que<br/><span className="g">transforma tu iglesia</span></h1>

          <p className="hero-p">
            En KHESED-TEK SYSTEMS convergen la vanguardia tecnológica y el propósito divino.
            Nuestra solución insignia, KHESED-TEK-CMS, nace de una convicción profunda: el
            software no es el fin, sino el medio estratégico para potenciar el cumplimiento
            de La Gran Comisión.
          </p>
          <p className="hero-verse">
            "Sé diligente en conocer el estado de tus ovejas, y mira con cuidado por tus rebaños" — Proverbios 27:23
          </p>

          <div className="hero-acts">
            <a href="/contact" className="btn-primary">
              Hablar con nosotros
              <Icon id="ico-arrow" size={16} color="var(--navy)" />
            </a>
            <a href="https://wa.me/573021234410" target="_blank" rel="noopener" className="btn-wa">
              <Icon id="ico-message" size={16} />
              WhatsApp directo
            </a>
          </div>

          <div className="hero-trust">
            <span className="trust-chip"><Icon id="ico-clock" size={14} color="var(--gold-hi)" />Soporte horario LATAM</span>
            <span className="sep" />
            <span className="trust-chip"><Icon id="ico-message" size={14} color="var(--gold-hi)" />Atención en español</span>
            <span className="sep" />
            <span className="trust-chip"><Icon id="ico-users" size={14} color="var(--gold-hi)" />Especialistas en iglesias</span>
          </div>
        </div>
      </section>

      {/* ── FOUNDER STORY ────────────────────────────────────── */}
      <section id="story" style={{ padding: '64px 0', background: 'var(--srf-lo)', borderTop: '1px solid var(--bdr)', borderBottom: '1px solid var(--bdr)' }}>
        <div className="wrap">
          <div className="tc rv" style={{ marginBottom: 10 }}>
            <div className="sec-lbl center">La empresa</div>
            <h2>La Historia Detrás de<br/><span className="g">KHESED-TEK</span></h2>
            <p className="sec-sub" style={{ maxWidth: 560, margin: '0 auto 28px' }}>
              Nuestra Misión: Usar la tecnología como una expresión práctica del 'Khesed' de Dios para servir a Su Iglesia.
            </p>
          </div>
          <div className="rv" style={{ maxWidth: 800, margin: '0 auto' }}>
            <div
              className="video-box"
              onClick={() => window.open('https://www.youtube.com/watch?v=d4rKaIUTCQQ', '_blank')}
              role="button" tabIndex={0}
              aria-label="Ver Historia del Fundador en YouTube"
              onKeyDown={e => e.key === 'Enter' && window.open('https://www.youtube.com/watch?v=d4rKaIUTCQQ', '_blank')}
            >
              {/* Replace with next/image in production */}
              <img src="/images/demo-thumbnail-latam.png" alt="Historia del Fundador de KHESED-TEK" />
              <div className="vid-overlay">
                <div className="play-circle">
                  <Icon id="ico-play" size={22} color="var(--navy)" style={{ marginLeft: 3 }} />
                </div>
              </div>
              <div className="vid-dur">5:30</div>
            </div>
            <div className="tc" style={{ marginTop: 24 }}>
              <h3 style={{ fontFamily: 'var(--font-d)', fontSize: 18, fontWeight: 600, color: 'var(--txt)', marginBottom: 10 }}>
                La Historia Detrás de KHESED-TEK
              </h3>
              <p style={{ fontSize: 14, color: 'var(--muted)', maxWidth: 520, margin: '0 auto 22px', lineHeight: 1.7 }}>
                Conozca la historia personal del fundador y nuestra misión de usar la tecnología como expresión práctica del Khesed de Dios.
              </p>
              <div style={{ display: 'flex', justifyContent: 'center', gap: 12, flexWrap: 'wrap' }}>
                <button className="btn-primary" onClick={() => window.open('https://www.youtube.com/watch?v=d4rKaIUTCQQ', '_blank')}>
                  <Icon id="ico-play" size={15} color="var(--navy)" />
                  Ver Historia del Fundador
                </button>
                <a href="/contact" className="btn-ghost">
                  <Icon id="ico-pin" size={15} color="var(--gold-hi)" />
                  Agendar Videollamada
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── TRUST BADGES ─────────────────────────────────────── */}
      <section id="trust" style={{ padding: '44px 0' }}>
        <div className="wrap">
          <div className="tc rv" style={{ marginBottom: 22 }}>
            <h3 style={{ fontFamily: 'var(--font-d)', fontSize: 18, fontWeight: 600, color: 'var(--txt)', marginBottom: 6 }}>
              Seguridad y Confianza
            </h3>
            <p style={{ fontSize: 13, color: 'var(--muted)' }}>Protegemos tu información con los más altos estándares</p>
          </div>
          <div className="trust-grid">
            {trustItems.map((t, i) => (
              <div key={t.lbl} className={`trust-card rv d${(i % 6) + 1}`}>
                <div className="trust-ico"><Icon id={t.icon} size={28} color="var(--gold-hi)" /></div>
                <div className="trust-v">{t.val}</div>
                <div className="trust-lbl">{t.lbl}</div>
                <div className="trust-desc">{t.desc}</div>
              </div>
            ))}
          </div>
          <div className="trust-note rv" style={{ marginTop: 14 }}>
            <Icon id="ico-shield" size={16} color="var(--cyan)" style={{ marginTop: 1 }} />
            <span>
              <strong style={{ color: 'var(--txt)' }}>Compromiso de Seguridad:</strong> Todos los datos están encriptados en tránsito y en reposo.
              Cumplimos con el GDPR y la Ley 1581 de protección de datos de Colombia.
            </span>
          </div>
        </div>
      </section>

      {/* ── FEATURES ─────────────────────────────────────────── */}
      <section id="features" style={{ padding: '84px 0' }}>
        <div className="wrap">
          <div className="rv" style={{ marginBottom: 32 }}>
            <div className="sec-lbl">Diferenciadores</div>
            <h2>Características únicas para <span className="g">Latinoamérica</span></h2>
            <p className="sec-sub" style={{ maxWidth: 520 }}>Capacidades culturalmente adaptadas que ningún competidor internacional ofrece.</p>
          </div>
          <div className="tc rv" style={{ marginBottom: 32 }}>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '7px 16px', borderRadius: 20, background: 'rgba(201,146,42,.08)', border: '1px solid rgba(201,146,42,.22)', fontSize: 11, letterSpacing: '.1em', textTransform: 'uppercase' as const, color: 'var(--gold-hi)' }}>
              <Icon id="ico-gem" size={13} color="var(--cyan)" />
              Superando a Planning Center, Breeze y ChurchTrac en el mercado latino
            </div>
          </div>
          <div className="feat-grid">
            {features.map((f, i) => (
              <div key={f.title} className={`feat-card rv d${(i % 6) + 1}`} style={{ ['--fc' as string]: f.color }}>
                <div className="feat-badge">{f.badge}</div>
                <div className="feat-head">
                  <div className="ico-pill" style={{ color: f.color }}>
                    <Icon id={f.icon} size={20} />
                  </div>
                  <div className="feat-title">{f.title}</div>
                </div>
                <p className="feat-desc">{f.desc}</p>
                <div className="feat-vs">
                  <Icon id="ico-gem" size={10} />
                  {f.vs}
                </div>
              </div>
            ))}
          </div>
          <div className="why-box rv" style={{ marginTop: 24 }}>
            <h3><Icon id="ico-gem" size={18} color="var(--gold-hi)" />Por qué las iglesias eligen KHESED-TEK sobre los competidores</h3>
            <div className="why-grid">
              <div className="why-item"><strong>vs Planning Center (Inglés)</strong><p>Culturalmente adaptado + métodos de pago locales + soporte en español</p></div>
              <div className="why-item"><strong>vs Breeze / ChurchTrac</strong><p>IA avanzada + WhatsApp Business nativo incluido sin costo adicional</p></div>
              <div className="why-item"><strong>vs Aplos</strong><p>ChMS completo para toda la iglesia vs solo contabilidad</p></div>
            </div>
          </div>
        </div>
      </section>

      {/* ── IMPACT METRICS ───────────────────────────────────── */}
      <section style={{ padding: '60px 0', background: 'var(--srf-lo)', borderTop: '1px solid var(--bdr)', borderBottom: '1px solid var(--bdr)' }}>
        <div className="wrap">
          <div className="tc rv" style={{ marginBottom: 40 }}>
            <div className="sec-lbl center">Resultados</div>
            <h2>Potencial de impacto <span className="g">comprobado</span></h2>
            <p className="sec-sub" style={{ maxWidth: 480, margin: '0 auto' }}>Basado en estudios de la industria y benchmarks de iglesias similares</p>
          </div>
          <div className="impact-grid">
            {[
              { icon: 'ico-chart',   color: 'var(--gold-hi)', v: '30–50%', h: 'Eficiencia Administrativa',  sub: 'reducción en tiempo administrativo',    src: 'Iglesias que digitalizan procesos',      ben: 'Más tiempo para ministerio pastoral' },
              { icon: 'ico-users',   color: 'var(--cyan)',    v: '25–40%', h: 'Participación Digital',       sub: 'aumento en engagement de miembros',     src: 'Estudios de transformación digital',     ben: 'Mayor conexión con la congregación' },
              { icon: 'ico-payment', color: 'var(--emerald)', v: '60%',    h: 'Gestión Financiera',          sub: 'mejora en transparencia de donaciones', src: 'Plataformas de donaciones digitales',    ben: 'Incremento en contribuciones regulares' },
            ].map(m => (
              <div key={m.h} className="impact-card rv">
                <div className="ico-pill" style={{ color: m.color }}><Icon id={m.icon} size={20} /></div>
                <div className="impact-v">{m.v}</div>
                <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--txt)', marginBottom: 4 }}>{m.h}</p>
                <div className="impact-sub">{m.sub}</div>
                <div className="impact-src">Fuente: {m.src}</div>
                <div className="impact-benefit"><strong>Beneficio:</strong> {m.ben}</div>
              </div>
            ))}
          </div>
          <div style={{ textAlign: 'center', marginTop: 36 }} className="rv">
            <div style={{ maxWidth: 500, margin: '0 auto', padding: 28, borderRadius: 16, background: 'var(--srf)', border: '1px solid var(--bdr)', backdropFilter: 'blur(18px)', textAlign: 'center' }}>
              <h3 style={{ fontFamily: 'var(--font-d)', fontSize: 18, fontWeight: 600, color: 'var(--txt)', marginBottom: 10 }}>¿Listo para estos resultados?</h3>
              <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 20, lineHeight: 1.7 }}>Únete a nuestro programa beta y sé parte de las primeras iglesias en experimentar estos beneficios</p>
              <a href="/contact?program=beta" className="btn-primary">Comenzar Prueba Beta <Icon id="ico-arrow" size={15} color="var(--navy)" /></a>
            </div>
          </div>
        </div>
      </section>

      {/* ── PRICING ──────────────────────────────────────────── */}
      <section id="pricing" style={{ padding: '84px 0' }}>
        <div className="wrap">
          <div className="tc rv" style={{ marginBottom: 32 }}>
            <div className="sec-lbl center">Planes</div>
            <h2>Adaptados al <span className="g">mercado hispano</span></h2>
            <p className="sec-sub" style={{ maxWidth: 480, margin: '0 auto 8px' }}>Precio fijo por tamaño de iglesia — sin cargos adicionales por módulos</p>
          </div>
          <div className="tc rv" style={{ marginBottom: 36 }}>
            <div className="bill-toggle">
              <button className={`bill-btn${!annual ? ' active' : ''}`} onClick={() => setAnnual(false)}>Mensual</button>
              <button className={`bill-btn${annual ? ' active' : ''}`} onClick={() => setAnnual(true)}>
                Anual <span style={{ fontSize: 10, opacity: 0.75, marginLeft: 4 }}>2 meses gratis</span>
              </button>
            </div>
          </div>
          <div className="price-grid rv">
            {/* BÁSICO */}
            <div className="price-card">
              <div className="price-name">BÁSICO</div>
              <div className="price-tier">Iglesia Pequeña</div>
              <div className="price-amount">{prices.basic} <span className="per">/mes</span></div>
              <div className="price-mbr">Hasta 500 miembros</div>
              <div className="price-div" />
              <ul className="price-feats">
                {['Gestión básica de miembros','WhatsApp Business integrado','Hasta 5 licencias de usuario','Soporte en español','Pagos locales (Nequi, PSE, Efecty)'].map(f => (
                  <li key={f}><Icon id="ico-check" size={14} color="var(--emerald)" style={{ marginTop: 1 }} />{f}</li>
                ))}
              </ul>
              <button className="price-btn" onClick={() => window.location.href = '/contact'}>Solicitar Demo</button>
            </div>
            {/* PROFESIONAL */}
            <div className="price-card pop">
              <div className="pop-badge">Más popular</div>
              <div className="price-name" style={{ marginTop: 14 }}>PROFESIONAL</div>
              <div className="price-tier">Iglesia Mediana</div>
              <div className="price-amount">{prices.pro} <span className="per">/mes</span></div>
              <div className="price-mbr">Hasta 2,000 miembros</div>
              <div className="price-div" />
              <ul className="price-feats">
                {['Todo lo del plan Básico','Hasta 10 licencias de usuario','Gestión de eventos y actividades','Reportes avanzados con IA','Transmisiones en vivo integradas'].map(f => (
                  <li key={f}><Icon id="ico-check" size={14} color="var(--emerald)" style={{ marginTop: 1 }} />{f}</li>
                ))}
              </ul>
              <button className="price-btn gold" onClick={() => window.location.href = '/contact'}>
                Más popular <Icon id="ico-arrow" size={14} color="var(--navy)" style={{ display: 'inline', marginLeft: 4 }} />
              </button>
            </div>
            {/* EMPRESARIAL */}
            <div className="price-card">
              <div className="price-name">EMPRESARIAL</div>
              <div className="price-tier">Iglesia Grande</div>
              <div className="price-amount">Personalizado</div>
              <div className="price-mbr">Miembros ilimitados</div>
              <div className="price-div" />
              <ul className="price-feats">
                {['Todo lo del plan Profesional','Licencias ilimitadas','Multi-campus','API personalizada','Soporte prioritario dedicado'].map(f => (
                  <li key={f}><Icon id="ico-check" size={14} color="var(--emerald)" style={{ marginTop: 1 }} />{f}</li>
                ))}
              </ul>
              <button className="price-btn" onClick={() => window.location.href = '/contact'}>Solicitar Demo</button>
            </div>
          </div>
          <div className="price-foot rv">
            <Icon id="ico-payment" size={13} color="var(--cyan)" />
            Acepta PSE, Bancolombia, Efecty, Nequi y transferencias bancarias
            <span className="pdot" />
            <Icon id="ico-phone" size={13} color="var(--cyan)" />
            Soporte telefónico en español incluido
          </div>
        </div>
      </section>

      {/* ── COMPARISON TABLE ─────────────────────────────────── */}
      <section style={{ padding: '60px 0 84px', background: 'var(--srf-lo)', borderTop: '1px solid var(--bdr)' }}>
        <div className="wrap">
          <div className="tc rv" style={{ marginBottom: 32 }}>
            <div className="sec-lbl center">Detalles</div>
            <h2>Comparación <span className="g">detallada</span></h2>
            <p className="sec-sub" style={{ maxWidth: 480, margin: '0 auto' }}>Encuentra el plan perfecto para tu iglesia</p>
          </div>
          <div className="comp-wrap rv">
            <div style={{ overflowX: 'auto' }}>
              <table className="comp">
                <thead>
                  <tr>
                    <th style={{ textAlign: 'left', width: '40%' }}>Función</th>
                    <th>Básico</th><th className="hi">Profesional</th><th>Empresarial</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    ['Gestión de miembros',        '✓','✓','✓'],
                    ['Límite de miembros',          '500','2,000','Ilimitado'],
                    ['Licencias de usuario',        'Hasta 5','Hasta 10','Ilimitadas'],
                    ['WhatsApp Business nativo',    '✓','✓','✓'],
                    ['Pagos locales LATAM',         '✓','✓','✓'],
                    ['Motor de oración con IA',     '✓','✓','✓'],
                    ['Eventos y actividades',       '–','✓','✓'],
                    ['Reportes avanzados',          '–','✓','✓'],
                    ['Transmisiones en vivo',       '–','✓','✓'],
                    ['Multi-campus',                '–','–','✓'],
                    ['API personalizada',           '–','–','✓'],
                    ['Soporte prioritario',         '–','–','✓'],
                  ].map(([fn, b, p, e]) => (
                    <tr key={fn}>
                      <td><div className="fn">{fn}</div></td>
                      <td className="center"><span className={b === '✓' ? 'chk-y' : b === '–' ? 'chk-n' : 'comp-val'}>{b}</span></td>
                      <td className="center hi"><span className={p === '✓' ? 'chk-y' : p === '–' ? 'chk-n' : 'comp-val'}>{p}</span></td>
                      <td className="center"><span className={e === '✓' ? 'chk-y' : e === '–' ? 'chk-n' : 'comp-val'}>{e}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div style={{ padding: 22, textAlign: 'center', borderTop: '1px solid var(--bdr)' }}>
              <h4 style={{ fontSize: 14, fontWeight: 600, color: 'var(--txt)', marginBottom: 8 }}>¿Necesitas ayuda para decidir?</h4>
              <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 16 }}>Nuestro equipo puede ayudarte a elegir el plan perfecto</p>
              <a href="/contact" className="btn-primary">Solicitar Consulta Gratuita <Icon id="ico-arrow" size={14} color="var(--navy)" /></a>
            </div>
          </div>
        </div>
      </section>

      {/* ── ROI CALCULATOR ───────────────────────────────────── */}
      <section style={{ padding: '84px 0' }}>
        <div className="wrap">
          <div className="tc rv" style={{ marginBottom: 40 }}>
            <div className="sec-lbl center">Calculadora</div>
            <h2>Calcule su <span className="g">Retorno de Inversión</span></h2>
            <p className="sec-sub" style={{ maxWidth: 480, margin: '0 auto' }}>Descubra cuánto puede ahorrar su iglesia con KHESED-TEK</p>
          </div>
          <div className="roi-wrap rv">
            <div className="roi-hd">
              <div className="ico-pill lg" style={{ color: 'var(--gold-hi)' }}><Icon id="ico-calc" size={26} /></div>
              <div><h3>Calculadora de ROI</h3><p>Descubra cuánto puede ahorrar su iglesia</p></div>
            </div>
            <div className="roi-body">
              <div className="roi-field" style={{ marginBottom: 20 }}>
                <label>Tamaño de su iglesia</label>
                <div className="size-btns">
                  {['Pequeña · 500', 'Mediana · 2,000', 'Grande · 10,000+'].map((s, i) => {
                    const [lbl, sub] = s.split(' · ');
                    return (
                      <button key={lbl} className={`sz-btn${i === 1 ? ' active' : ''}`}>
                        <div>{lbl}</div><small>{sub} miembros</small>
                      </button>
                    );
                  })}
                </div>
              </div>
              <div className="roi-inputs">
                <div className="roi-field">
                  <label>Costo actual de software (mensual)</label>
                  <div className="input-wrap">
                    <span className="input-pre">$</span>
                    <input type="number" value={roiCost} onChange={e => setRoiCost(Number(e.target.value))} placeholder="200" />
                    <span className="input-suf">/mes</span>
                  </div>
                </div>
                <div className="roi-field">
                  <label>Horas administrativas por semana</label>
                  <div className="input-wrap">
                    <input type="number" value={roiHrs} onChange={e => setRoiHrs(Number(e.target.value))} min={1} max={40} style={{ paddingLeft: 12 }} />
                    <span className="input-suf">hrs/sem</span>
                  </div>
                </div>
              </div>
              <div className="roi-slider" style={{ marginBottom: 20 }}>
                <label>Nivel de procesos manuales</label>
                <input type="range" min={1} max={10} value={roiManual} onChange={e => setRoiManual(Number(e.target.value))} />
                <div className="slider-labels">
                  <span>Mínimos</span>
                  <span style={{ color: 'var(--gold-hi)', fontWeight: 600 }}>{roiManual}/10</span>
                  <span>Extensos</span>
                </div>
              </div>
              {roiResult && (
                <div className="roi-result-row">
                  <div className="roi-result">
                    <div className="roi-result-v">${roiResult.save.toLocaleString('es-CO')} USD</div>
                    <div className="roi-result-l">Ahorro mensual estimado</div>
                  </div>
                  <div className="roi-result">
                    <div className="roi-result-v">{roiResult.hrsSaved} hrs</div>
                    <div className="roi-result-l">Horas recuperadas por semana</div>
                  </div>
                </div>
              )}
              <button
                className="btn-primary"
                style={{ width: '100%', justifyContent: 'center' }}
                onClick={() => setRoiResult(calcROI(roiCost, roiHrs, roiManual))}
              >
                <Icon id="ico-calc" size={16} color="var(--navy)" />
                Calcular ROI
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ── MISSION / ABOUT ──────────────────────────────────── */}
      <section id="about" style={{ padding: '84px 0', background: 'var(--srf-lo)', borderTop: '1px solid var(--bdr)' }}>
        <div className="wrap" style={{ maxWidth: 840 }}>
          <div className="tc rv" style={{ marginBottom: 36 }}>
            <div className="sec-lbl center">Misión</div>
            <h2>Nuestra <span className="g">Misión</span></h2>
          </div>
          <div className="mission-card rv">
            <p className="lead">Nuestra misión es desplegar la tecnología como una expresión práctica del Khesed de Dios — Su amor de pacto y misericordia — para servir a Su Iglesia.</p>
            <p>Fieles a este llamado, transformamos nuestro trabajo en una ofrenda tangible: <strong style={{ color: 'var(--gold-hi)' }}>el 33% de todas las ganancias de nuestras suscripciones</strong> se asignan directamente para financiar las obras comunitarias de Misión Khesed.</p>
            <p>Este compromiso asegura que cada solución tecnológica que creamos se convierta en un acto de amor práctico y generacional.</p>
            <p className="italic">Porque creemos que servir a la Iglesia es también servir al mundo al cual Ella es enviada.</p>
            <div className="mission-verse">
              <strong>Fundamento Bíblico</strong>
              <p>"Sé diligente en conocer el estado de tus ovejas, y mira con cuidado por tus rebaños" — Proverbios 27:23</p>
            </div>
          </div>
          <p className="rv" style={{ fontSize: 15, color: 'var(--muted)', lineHeight: 1.8, marginBottom: 16 }}>
            Somos una firma innovadora de software con sede en Barranquilla, dedicada exclusivamente a servir al Reino.
            Empoderamos a organizaciones basadas en la fe mediante soluciones de Inteligencia Artificial e integración
            de procesos, resolviendo sus desafíos operativos más complejos.
          </p>
          <p className="rv" style={{ fontSize: 15, color: 'var(--muted)', lineHeight: 1.8, marginBottom: 36 }}>
            Optimizamos sus tareas administrativas para que su equipo recupere el activo más valioso: tiempo para
            pastorear y fortalecer a la comunidad, mientras nosotros gestionamos la complejidad tecnológica.
          </p>
          <div className="about-stats rv">
            {[['10K+','Miembros soportados'],['40+','Años experiencia ministerial'],['99.9%','Uptime garantizado'],['15+','Integraciones disponibles']].map(([v,l]) => (
              <div key={l} className="astat"><div className="astat-v">{v}</div><div className="astat-l">{l}</div></div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CONTACT ──────────────────────────────────────────── */}
      <section id="contact" style={{ padding: '84px 0' }}>
        <div className="wrap" style={{ maxWidth: 800 }}>
          <div className="tc rv" style={{ marginBottom: 36 }}>
            <div className="sec-lbl center">Conversemos</div>
            <h2>Hablemos sobre <span className="g">tu iglesia</span></h2>
            <p className="sec-sub" style={{ maxWidth: 480, margin: '0 auto' }}>Nuestro equipo en Barranquilla está listo para ayudarte</p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }} className="rv">
            <div style={{ padding: 28, borderRadius: 'var(--r)', background: 'var(--srf)', border: '1px solid var(--bdr-s)', backdropFilter: 'blur(18px)' }}>
              <h3 style={{ fontFamily: 'var(--font-d)', fontSize: 14, fontWeight: 600, color: 'var(--txt)', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 10 }}>
                <Icon id="ico-email" size={16} color="var(--cyan)" />Contacto directo
              </h3>
              {[
                { icon: 'ico-email', text: 'contacto@khesed-tek-systems.org' },
                { icon: 'ico-phone', text: '+57 302 123 4410 (WhatsApp)' },
                { icon: 'ico-pin',   text: 'Barranquilla, Atlántico, Colombia' },
                { icon: 'ico-clock', text: 'Lunes a Viernes · 9AM–6PM (COT)' },
              ].map(r => (
                <div key={r.text} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12, fontSize: 13, color: 'var(--muted)' }}>
                  <Icon id={r.icon} size={14} color="var(--gold-hi)" />
                  {r.text}
                </div>
              ))}
            </div>
            <div style={{ padding: 28, borderRadius: 'var(--r)', background: 'var(--srf)', border: '1px solid var(--bdr-s)', backdropFilter: 'blur(18px)' }}>
              <h3 style={{ fontFamily: 'var(--font-d)', fontSize: 14, fontWeight: 600, color: 'var(--txt)', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 10 }}>
                <Icon id="ico-users" size={16} color="var(--cyan)" />Demo personalizada
              </h3>
              {['Demostración adaptada a tu iglesia','Análisis de necesidades sin costo','Plan de implementación personalizado','Acompañamiento en tu zona horaria'].map(f => (
                <div key={f} style={{ display: 'flex', alignItems: 'flex-start', gap: 9, fontSize: 13, color: 'var(--muted)', marginBottom: 10 }}>
                  <Icon id="ico-check" size={13} color="var(--emerald)" style={{ marginTop: 3 }} />{f}
                </div>
              ))}
              <a href="/schedule" className="btn-primary" style={{ display: 'inline-flex', width: '100%', justifyContent: 'center', marginTop: 8 }}>
                Agendar Videollamada <Icon id="ico-arrow" size={14} color="var(--navy)" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ── FAQ ──────────────────────────────────────────────── */}
      <section id="faq" style={{ padding: '60px 0 84px', background: 'var(--srf-lo)', borderTop: '1px solid var(--bdr)' }}>
        <div className="wrap">
          <div className="tc rv" style={{ marginBottom: 40 }}>
            <div className="sec-lbl center">FAQ</div>
            <h2>Preguntas <span className="g">frecuentes</span></h2>
            <p className="sec-sub" style={{ maxWidth: 480, margin: '0 auto' }}>¿Tiene dudas? Aquí respondemos las más comunes.</p>
          </div>
          <div className="faq-list">
            {faqs.map((f, i) => (
              <div key={i} className={`faq-item rv d${(i % 6) + 1}${openFaq === i ? ' open' : ''}`}>
                <button className="faq-btn" onClick={() => setOpenFaq(openFaq === i ? null : i)}>
                  {f.q}
                  <Icon id="ico-chevron" size={18} color="var(--gold-hi)" style={{ flexShrink: 0, transition: 'transform .3s', transform: openFaq === i ? 'rotate(180deg)' : 'none' }} />
                </button>
                <div className="faq-ans" style={{ maxHeight: openFaq === i ? 260 : 0, paddingBottom: openFaq === i ? 18 : 0 }}>
                  {f.a}
                </div>
              </div>
            ))}
          </div>
          <div className="faq-more rv">
            <a href="/contact" style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 14, color: 'var(--gold-hi)', fontWeight: 500 }}>
              ¿Otra pregunta? Escríbanos
              <Icon id="ico-arrow" size={14} />
            </a>
          </div>
        </div>
      </section>

      {/* ── FOOTER ───────────────────────────────────────────── */}
      <footer className="z1">
        <div className="wrap">
          <div className="foot-grid">
            <div className="foot-brand">
              <KhesedLogo height={40} />
              <p>Tecnología pastoral con propósito, construida para iglesias en Latinoamérica. El 33% de nuestras ganancias financia Misión Khesed.</p>
              <div className="social-links">
                {socials.map(s => (
                  <a key={s.id} href={s.href} target="_blank" rel="noopener" aria-label={s.label}>
                    <Icon id={s.id} size={18} />
                  </a>
                ))}
              </div>
            </div>
            <div className="foot-col">
              <h4>Plataforma</h4>
              <ul><li><a href="#features">Funciones</a></li><li><a href="#pricing">Precios</a></li><li><a href="/products">Productos</a></li><li><a href="/schedule">Agendar Demo</a></li></ul>
            </div>
            <div className="foot-col">
              <h4>Empresa</h4>
              <ul><li><a href="#about">Nosotros</a></li><li><a href="https://www.youtube.com/watch?v=d4rKaIUTCQQ" target="_blank" rel="noopener">Historia del Fundador</a></li><li><a href="#contact">Contacto</a></li></ul>
            </div>
            <div className="foot-col">
              <h4>Legal</h4>
              <ul><li><a href="/privacy">Política de Privacidad</a></li><li><a href="/terms">Términos de Servicio</a></li></ul>
              <div style={{ marginTop: 16, fontSize: 12, color: 'var(--muted)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                  <Icon id="ico-email" size={12} color="var(--gold-hi)" />
                  <a href="mailto:contacto@khesed-tek-systems.org" style={{ color: 'var(--muted)' }}>contacto@khesed-tek-systems.org</a>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <Icon id="ico-phone" size={12} color="var(--gold-hi)" />
                  <a href="https://wa.me/573021234410" target="_blank" rel="noopener" style={{ color: 'var(--muted)' }}>+57 302 123 4410</a>
                </div>
              </div>
            </div>
          </div>
          <div className="foot-bottom">
            <p>© 2026 KHESED-TEK SYSTEMS. Barranquilla, Atlántico, Colombia. Todos los derechos reservados.</p>
            <div className="foot-status">
              <div className="foot-status-dot" />
              Todos los sistemas operativos
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}

// React import needed for useState
import React from 'react';
